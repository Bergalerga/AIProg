package org.ntnu.it3105.game;

/**
 * Created by berg on 13/10/15.
 */
public class Test {
    public static void main(String[] args) {
        int[][] board = new int[9][9];
        System.out.println(board);
    }
}
